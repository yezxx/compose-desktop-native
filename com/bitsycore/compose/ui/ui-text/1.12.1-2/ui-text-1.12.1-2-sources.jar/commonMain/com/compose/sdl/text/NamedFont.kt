package com.compose.sdl.text

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontListFontFamily
import androidx.compose.ui.text.font.FontLoadingStrategy
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight

// ==================
// MARK: NamedFont - project name-based Font
// ==================

/**
 * A project-specific [Font] that carries a family name rather than a resource id / bytes.
 * The SDL3 / Skia text renderer looks up the actual bytes at draw time via
 * [com.compose.sdl.text.TextMeasurer]'s registered font table.
 *
 * Upstream's `FontFamily.Named` project extension is retired - vendored `FontFamily`
 * is a `sealed class` whose only `FontListFontFamily` / `GenericFontFamily` /
 * `LoadedFontFamily` branches don't accept project subclasses. Instead, we route
 * name-based lookups through the standard `Font → FontFamily` chain: pass
 * `namedFontFamily("noto-mono")` (returns a `FontListFontFamily`) as
 * `TextStyle.fontFamily`, and the renderer extracts the family name via
 * [FontFamily.projectFontName].
 */
class NamedFont(
	val name: String,
	override val weight: FontWeight = FontWeight.Normal,
	override val style: FontStyle = FontStyle.Normal,
	val variationSettings: FontVariation.Settings = FontVariation.Settings(weight, style),
	// Raw variable-font axis settings (Material Symbols FILL/wght/GRAD/opsz),
	// threaded through the family so the skiko text engine can apply them via
	// FontFamily.projectFontVariations() - icons render on the standard text path.
	val axes: List<FontVariation.Setting>? = null,
) : Font {
	override val loadingStrategy: FontLoadingStrategy = FontLoadingStrategy.Blocking

	override fun equals(other: Any?): Boolean =
		other is NamedFont && other.name == name && other.weight == weight && other.style == style &&
			other.axes == axes && other.variationSettings == variationSettings

	override fun hashCode(): Int {
		var h = name.hashCode()
		h = 31 * h + weight.hashCode()
		h = 31 * h + style.hashCode()
		// Axis settings (Material Symbols FILL/wght/GRAD/opsz) are part of identity -
		// without them two axis-differing icon fonts compare equal and collide in the
		// FontFamily → typeface cache, rendering one icon's axes for the other.
		h = 31 * h + (axes?.hashCode() ?: 0)
		h = 31 * h + variationSettings.hashCode()
		return h
	}

	override fun toString(): String = "NamedFont(name=$name, weight=$weight, style=$style)"
}

/** Convenience factory - the vendored `FontFamily(vararg fonts)` factory wraps into a
 *  `FontListFontFamily`. Replaces the deleted project extension `FontFamily.Named(name)`. */
fun namedFontFamily(
	name: String,
	weight: FontWeight = FontWeight.Normal,
	style: FontStyle = FontStyle.Normal,
	axes: List<FontVariation.Setting>? = null,
): FontFamily = FontFamily(NamedFont(name, weight, style, axes = axes))

/**
 * Extract the renderer font-registry name for a `FontFamily`:
 *   * a [namedFontFamily] (`FontListFontFamily` whose first font is a [NamedFont]) → its name -
 *     or, when [style] is given, the name of the family's [NamedFont] with that style
 *     (`FontFamily(Font(Res.font.x), Font(Res.font.x_italic, style = Italic))` renders the
 *     real italic file), falling back to the first;
 *   * a generic `FontFamily.Monospace` / `Serif` / `Cursive` → `"generic:<name>"`, which the
 *     renderer resolves to the bundled generic font (registerGenericFonts), falling back to the
 *     default font when that generic isn't bundled;
 *   * everything else (`Default`, `SansSerif`, `LoadedFontFamily`, resource-backed lists) → `null`
 *     (the default font).
 */
fun FontFamily?.projectFontName(style: FontStyle? = null): String? = when (this) {
	is FontListFontFamily -> {
		val vFirst = firstOrNull() as? NamedFont
		if (vFirst == null || style == null) vFirst?.name
		else (fonts.firstOrNull { it is NamedFont && it.style == style } as? NamedFont ?: vFirst).name
	}
	is androidx.compose.ui.text.font.GenericFontFamily ->
		if (name == "sans-serif") null else "generic:$name"
	else -> null
}

/** Variable-font axis settings carried by a [namedFontFamily]'s [NamedFont]
 *  (Material Symbols FILL/wght/GRAD/opsz); null for every other family. The
 *  skiko text engine applies these on top of / instead of the paragraph weight. */
fun FontFamily?.projectFontVariations(): List<FontVariation.Setting>? =
	((this as? FontListFontFamily)?.firstOrNull() as? NamedFont)?.axes
